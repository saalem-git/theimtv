<!DOCTYPE html>
<html>

<head>
        <?php echo $__env->make('blade-scafolding.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('blade-scafolding.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--     <div class="landingpage" id="landingpage">.</div>
 -->
 <div class"content">

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
            <?php echo $__env->make('blade-scafolding.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

    </div>

    <!-- this slide should inherit the sizes attr from the parent slider -->
    <img data-lazy="http://placehold.it/350x300?text=6-350w" data-srcset="http://placehold.it/650x300?text=6-650w 650w, http://placehold.it/960x300?text=6-960w 960w">

    <?php echo $__env->make('blade-scafolding.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH /Users/Saalem/laravelApps/theimtv/resources/views/blade-scafolding/layout/master.blade.php ENDPATH**/ ?>