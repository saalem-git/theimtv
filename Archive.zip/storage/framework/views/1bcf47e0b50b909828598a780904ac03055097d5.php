<div class="footer col-md-12">
        <div class="col-md-12">
            <i class="fa fa-facebook fa-2x footer-icons"></i>
            <i class="fa fa-instagram fa-2x footer-icons"></i>
            <i class="fa fa-twitter fa-2x footer-icons"></i>
            <i class="fa fa-youtube fa-2x footer-icons"></i>
        </div>

        <div class="col-md-12 col-sm-12">
            <div class="col-md-3 col-sm-3">
                <li><a href="#">Audio and Subtitles</a></li>
                <li><a href="#">Media Centre</a></li>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">Contact Us</a></li>
            </div>
            <div class="col-md-3 col-sm-3">
                <li><a href="#">Audio Description</a></li>
                <li><a href="#">Investor Relations</a></li>
                <li><a href="#">Legal Notices</a></li>
            </div>
            <div class="col-md-3 col-sm-3">
                <li><a href="#">Help Center</a></li>
                <li><a href="#">Jobs</a></li>
                <li><a href="#">Cookies Preferences</a></li>
            </div>
            <div class="col-md-3 col-sm-3">
                <li><a href="#">Gift Cards</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Corporate Information</a></li>
            </div>
        </div>
        <div class="col-md-12 copyright">
            <h4>A Collaborative Effort with</h4>
            <img class="rtm" src="assets/rtm-finas.png">
            <p>© 2019 Insight Malaysia, All Right Reserved</p>
        </div>
    </div><?php /**PATH /Users/Saalem/laravelApps/theimtv/resources/views/partials/footer.blade.php ENDPATH**/ ?>